package Utlities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.function.Function;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class base {

    public static WebDriver driver;
    public static Logger log;
    public static Properties prop;

    // Logger setup
    public void setupLogger() {
        log = Logger.getLogger("loggerfile");
        PropertyConfigurator.configure("src/test/resource/log4j.properties");
        log.info("Logger configured successfully");
    }

    // Config setup
    public void loadConfig() {
        prop = new Properties();
        try {
            FileInputStream fis = new FileInputStream("src/test/resource/config.properties");
            prop.load(fis);
            log.info("Config file loaded successfully");
        } catch (IOException e) {
            log.error("Error loading config file: " + e.getMessage());
        }
    }

    // Launch Chrome
    public void launch_chrome() {
        setupLogger();
        loadConfig();
        String url = prop.getProperty("url");
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        driver = new ChromeDriver();
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        log.info("Chrome launched on: " + url);
    }

    // Launch Edge
    public void launch_edge() {
        setupLogger();
        loadConfig();
        String url = prop.getProperty("url");
        System.setProperty("webdriver.edge.driver", "msedgedriver_v141.exe");
        driver = new EdgeDriver();
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        log.info("Edge launched on: " + url);
    }

    // Launch Firefox
    public void launch_firefox() {
        setupLogger();
        loadConfig();
        String url = prop.getProperty("url");
        System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
        driver = new FirefoxDriver();
        driver.get(url);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        log.info("Firefox launched on: " + url);
    }

    // Close browser
    public void close_browser() {
        driver.quit();
        log.info("Browser closed successfully");
    }

    // Explicit Wait
    public void waitForElement(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOf(element));
            log.info("Element visible: " + element.toString());
        } catch (Exception e) {
            log.error("Error waiting for element: " + e.getMessage());
        }
    }

    // Fluent Wait
    public WebElement fluentWait(WebElement element) {
        FluentWait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);

        try {
            return wait.until(new Function<WebDriver, WebElement>() {
                public WebElement apply(WebDriver driver) {
                    return element.isDisplayed() ? element : null;
                }
            });
        } catch (Exception e) {
            log.error("FluentWait failed: " + e.getMessage());
            return null;
        }
    }
}

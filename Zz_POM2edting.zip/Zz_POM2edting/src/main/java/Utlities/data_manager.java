package Utlities;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class data_manager {

    Logger log = LogManager.getLogger(data_manager.class);

    // Method to read Excel file and return list of rows (each as String array)
    public List<String[]> readExcelData(String filePath) {
        List<String[]> dataList = new ArrayList<>();

        try {
            FileInputStream file = new FileInputStream(new File(filePath));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                XSSFRow row = sheet.getRow(i);

                int cellCount = row.getPhysicalNumberOfCells();
                String[] rowData = new String[cellCount];

                for (int j = 0; j < cellCount; j++) {
                    rowData[j] = row.getCell(j).toString();
                }

                dataList.add(rowData);
            }

            workbook.close();
            file.close();
            log.info("Excel data read successfully from: " + filePath);

        } catch (Exception e) {
            log.error("Error reading Excel file: " + e.getMessage());
        }

        return dataList;
    }
}

package tests;

import org.testng.Assert;
import org.testng.annotations.*;
import Pages.P1_register_page;
import Pages.P2_login_page;
import Pages.P3_text_page;
import Utlities.base;
import Utlities.data_manager;

import java.util.List;

public class TestCases_ed extends base {

    P1_register_page rp;
    P2_login_page lp;
    P3_text_page tp;
    data_manager dm;
    List<String[]> testData;

    String firstname = "deep1";
    String lastname = "__";
    String email = "absdfaa31811@gmail.com";
    String password = "Deep@2809";
    String confirmpassword = "Deep@2809";

    @BeforeClass
    public void setup() {
        setupLogger();         // initialize logger
        loadConfig();          // load config.properties
        launch_edge();       // launch only Edge

        dm = new data_manager();
        testData = dm.readExcelData("Exceltest.xlsx");

        rp = new P1_register_page(driver);
        lp = new P2_login_page(driver);
        tp = new P3_text_page(driver);

        log.info("Setup completed for Chrome browser");
    }

    @Test(priority = 1)
    public void registerUser() {
        rp.click_bt();
        rp.select_g();
        rp.enter_firstname(firstname);
        rp.enter_lastname(lastname);
        rp.enter_email(email);
        rp.enter_password(password);
        rp.enter_confirmedpassword(confirmpassword);
        rp.register_click();
        rp.click_logout();
        log.info("registerUser Completed");
    }

    @Test(priority = 2)
    public void verifyComputersText() {
        lp.click_bt();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getComputersText();
        String expected = testData.get(0)[0];
        Assert.assertEquals(text, expected);
        log.info("Verified Computers: " + text);
        lp.click_logout();
    }

    @Test(priority = 3)
    public void verifyElectronicsText() {
        lp.click_bt();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getElectronicsText();
        String expected = testData.get(0)[1];
        Assert.assertEquals(text, expected);
        log.info("Verified Electronics: " + text);
        lp.click_logout();
    }

    @Test(priority = 4)
    public void verifyApparelText() {
        lp.click_bt();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getApparelText();
        String expected = testData.get(0)[2];
        Assert.assertEquals(text, expected);
        log.info("Verified Apparel: " + text);
        lp.click_logout();
    }

    @AfterClass
    public void closeBrowser() {
        close_browser();
        log.info("Browser closed");
    }
}

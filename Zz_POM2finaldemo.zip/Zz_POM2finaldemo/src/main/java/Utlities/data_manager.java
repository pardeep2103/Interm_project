package Utlities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class data_manager {
    Properties prop;
    Logger log = LogManager.getLogger(data_manager.class);

    public data_manager() {
        prop = new Properties();
        try {
            FileInputStream fis = new FileInputStream("resource//config.properties");
            prop.load(fis);
            log.info("Config file loaded successfully");
        } catch (IOException e) {
            log.error("Error loading config file: " + e.getMessage());
        }
    }

    public String getProperty(String key) {
        return prop.getProperty(key);
    }

    public List<String[]> readExcelData(String filePath) {
        List<String[]> data = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook wb = new XSSFWorkbook(fis)) {
            Sheet sheet = wb.getSheetAt(0);
            for (Row row : sheet) {
                String[] rowData = new String[row.getPhysicalNumberOfCells()];
                for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
                    rowData[i] = row.getCell(i).getStringCellValue();
                }
                data.add(rowData);
            }
            log.info("Excel data read successfully from: " + filePath);
        } catch (IOException e) {
            log.error("Error reading Excel file: " + e.getMessage());
        }
        return data;
    }
}
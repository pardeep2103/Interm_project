package Utlities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
//] org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.function.Function;

public class base {
    public static WebDriver driver;
    Logger log = LogManager.getLogger(base.class);
    Properties prop;


public base() {
    prop = new Properties();
    try {
        FileInputStream fis = new FileInputStream("src/test/resource/config.properties");
        prop.load(fis);
        PropertyConfigurator.configure("src/test/resource/log4j.properties");
        log.info("Config and Log4j initialized successfully");
    } catch (IOException e) {
        log.error("Error loading config file: " + e.getMessage());
    }
}


    public void launch_chrome() {
        System.setProperty("webdriver.chrome.driver", "chromedriver_v141.exe");
        driver = new ChromeDriver();
        driver.get("https://demo.nopcommerce.com/");
        driver.manage().window().maximize();
    }

    public void launch_edge() {
        System.setProperty("webdriver.edge.driver", "msedgedriver_v141.exe");
        driver = new EdgeDriver();
        driver.get("https://demo.nopcommerce.com/");
        driver.manage().window().maximize();
    }

    public void close_browser() {
        driver.quit();
    }

    // Explicit Wait 
       public void waitForElement(WebElement element) {
           WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
           wait.until(ExpectedConditions.visibilityOf(element));
       }

       // Fluent Wait 
       public WebElement fluentWait(WebElement element) {
           FluentWait<WebDriver> wait = new FluentWait<>(driver)
                   .withTimeout(Duration.ofSeconds(30))   
                   .pollingEvery(Duration.ofSeconds(2))  
                   .ignoring(NoSuchElementException.class);

           return wait.until(new Function<WebDriver, WebElement>() {
               public WebElement apply(WebDriver driver) {
                   return element.isDisplayed() ? element : null;
               }
           });
       }
   }


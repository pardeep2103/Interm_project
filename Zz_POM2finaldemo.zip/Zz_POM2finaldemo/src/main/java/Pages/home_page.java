package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class home_page {
    WebDriver driver;


	
	  @FindBy(xpath = "//a[@class='ico-register']")
	    WebElement rb_button;
	  @FindBy(xpath = "//a[@class='ico-login']")
	    WebElement login1;


public home_page(WebDriver driver) {
    this.driver = driver;
    PageFactory.initElements(driver, this);
}
public void click_bt() {
    rb_button.click();
}
public void click_login() {
    login1.click();
}
}
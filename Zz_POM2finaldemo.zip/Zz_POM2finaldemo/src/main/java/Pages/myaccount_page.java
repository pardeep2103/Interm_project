package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class myaccount_page {
    WebDriver driver;

    @FindBy(xpath = "//div[@class='header-menu']//ul[1]//li[1]//a[@href='/computers']")
    WebElement computersText;

    @FindBy(xpath = "//div[@class='header-menu']//ul[1]//li[2]//a[@href='/electronics']")
    WebElement electronicsText;

    @FindBy(xpath = "//div[@class='header-menu']//ul[1]//li[3]//a[@href='/apparel']")
    WebElement apparelText;

    @FindBy(xpath = "//a[@class='ico-logout']")
    WebElement logoutclick;
    
    public myaccount_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public String getComputersText() {
        return computersText.getText();
    }

    public String getElectronicsText() {
        return electronicsText.getText();
    }

    public String getApparelText() {
        return apparelText.getText();
    }
    public void click_logout() {
        logoutclick.click();
    }

}
package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class register_page {
    WebDriver driver;
    
  
    
    @FindBy(xpath ="//input[@value='M'] ")
    WebElement morf;
    
    @FindBy(xpath = "//input[@id='FirstName']")
    WebElement enter_fn;
    
    @FindBy(xpath = "//input[@id='LastName']")
    WebElement enter_ln;
    
    @FindBy(xpath = "//input[@id='Email']")
    WebElement enter_em;
    
    @FindBy(xpath = "//input[@id='Password']")
    WebElement enter_password;
    
    @FindBy(xpath = "//input[@id='ConfirmPassword']")
    WebElement enter_cp;
    
    @FindBy(xpath = "//button[@id='register-button']")
    
    WebElement click_rb;
  

    
    public register_page(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
   
    public void select_g() {
    	morf.click();
    }
    public void enter_firstname(String firstname ) {
    	enter_fn.sendKeys(firstname);
    }
    public void enter_lastname(String lastname) {
    	enter_ln.sendKeys(lastname);
    }
    public void enter_email(String email) {
    	enter_em.sendKeys(email);
    }
    public void enter_password(String password) {
    	enter_password.sendKeys(password);
    }
    
   public void enter_confirmedpassword( String confirmedpassword) {
	   enter_cp.sendKeys(confirmedpassword);
   }
public void register_click(){
	click_rb.click();
	
}

}

    
    
    



package tests;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.home_page;
import Pages.register_page;
import Pages.login_page;
import Pages.myaccount_page;
import Utlities.base;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TestCases_ch extends base {
	home_page cb;
	register_page rp;
    login_page lp;
    myaccount_page tp;

    // Test Data 
    String firstname = "deep1";
    String lastname = "__";
    String email = "ad91sdf@gmail.com";
    String password = "Deep@2809";
    String confirmpassword = "Deep@2809";

    Logger log = LogManager.getLogger(TestCases_ch.class);

    @BeforeClass
    public void setup() {
        log.info("Launching Chrome browser");
        launch_chrome();
        rp = new register_page(driver);
        lp = new login_page(driver);
        tp = new myaccount_page(driver);
        cb = new home_page(driver);
        log.info("Setup completed for Chrome test class");
    }

    @Test(priority = 1)
    public void registerUser() {
        log.info("Starting registerUser test");
        cb.click_bt();
        rp.select_g();
        rp.enter_firstname(firstname);
        rp.enter_lastname(lastname);
        rp.enter_email(email);
        rp.enter_password(password);
        rp.enter_confirmedpassword(confirmpassword);
        rp.register_click();
        tp.click_logout();
        log.info("registerUser test completed successfully");
    }

    @Test(priority = 2)
    public void verifyComputersText() {
        log.info("Starting verifyComputersText test");
        cb.click_login();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getComputersText();
        Assert.assertEquals(text, "Computers");
        log.info("Verified Computers text successfully: " + text);

        tp.click_logout();
    }

    @Test(priority = 3)
    public void verifyElectronicsText() {
        log.info("Starting verifyElectronicsText test");
        cb.click_login();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getElectronicsText();
        Assert.assertEquals(text, "Electronics");
        log.info("Verified Electronics text successfully: " + text);

        tp.click_logout();
    }

    @Test(priority = 4)
    public void verifyApparelText() {
        log.info("Starting verifyApparelText test");
        cb.click_login();
        lp.enter_usern(email);
        lp.enter_passw(password);
        lp.click_login();

        String text = tp.getApparelText();
        Assert.assertEquals(text, "Apparel");
        log.info("Verified Apparel text successfully: " + text);

        tp.click_logout();
    }

    @AfterClass
    public void closes() {
        close_browser();
        log.info("Chrome browser closed after all tests");
    }
}
